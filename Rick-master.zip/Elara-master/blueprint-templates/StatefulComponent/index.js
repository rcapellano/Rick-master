import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

export default class {{ pascalCase name }} extends React.Component {
   static propTypes = {

   }

   state = {
      value: null,
   }

   componentDidMount() => {
   }

   componentWillUnmount() => {
   }

   render() {
      return (
         <div>
            {{ pascalCase name }}
         </div>
      );
   }
}
