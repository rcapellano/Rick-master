import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const {{pascalCase name}} = props => (
   <div>
      {{pascalCase name}}
   </div>
)

{{pascalCase name}}.propTypes = {

}

export default {{pascalCase name}}
