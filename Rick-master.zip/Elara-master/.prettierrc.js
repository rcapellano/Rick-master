module.exports = {
   trailingComma: 'none',
   tabWidth: 3,
   semi: false,
   singleQuote: true,
   printWidth: 160
}
