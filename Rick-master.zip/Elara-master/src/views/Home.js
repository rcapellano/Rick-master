import React from 'react'

const Home = () => (
   <div>
      Hey!
   </div>
)

export default Home
